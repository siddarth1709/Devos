# DevOS CLI

A modular, local-first developer command line interface.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
python -m pip install -e .
```

## Try it

```bash
devos
devos init demo-project
cd demo-project
devos analyze
devos review
devos diagnose
devos git status
devos ask "Explain this project"
devos help
```

The initial `ask` command is an integration-ready local placeholder, not a connected LLM.
No source files are modified by `review`, `diagnose`, or `analyze`.
