from __future__ import annotations

import json
import os
import subprocess
from collections import Counter
from pathlib import Path
from typing import Optional

import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree

app = typer.Typer(
    name="devos",
    help="DevOS — an intelligent command layer for software development.",
    no_args_is_help=False,
    add_completion=True,
)
console = Console()

SKIP_DIRS = {
    ".git", ".venv", "venv", "node_modules", "__pycache__", ".next",
    "dist", "build", ".idea", ".pytest_cache", ".mypy_cache"
}
SOURCE_EXTENSIONS = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".go", ".rs",
    ".cpp", ".c", ".h", ".cs", ".php", ".rb", ".swift", ".kt",
    ".html", ".css", ".scss", ".sql", ".sh"
}


def banner() -> None:
    art = (
        "[bold orange1]██████╗ ███████╗██╗   ██╗ ██████╗ ███████╗[/]\n"
        "[bold orange1]██╔══██╗██╔════╝██║   ██║██╔═══██╗██╔════╝[/]\n"
        "[bold orange1]██║  ██║█████╗  ██║   ██║██║   ██║███████╗[/]\n"
        "[bold orange1]██║  ██║██╔══╝  ╚██╗ ██╔╝██║   ██║╚════██║[/]\n"
        "[bold orange1]██████╔╝███████╗ ╚████╔╝ ╚██████╔╝███████║[/]\n"
        "[bold orange1]╚═════╝ ╚══════╝  ╚═══╝   ╚═════╝ ╚══════╝[/]"
    )
    console.print(Panel.fit(
        art + "\n\n[bold white]Developer Operating System[/]\n"
        "[dim]AI-ready development environment  •  v0.1.0[/]\n"
        "[green]●[/] Local CLI ready",
        border_style="orange1",
        padding=(1, 3),
    ))
    console.print("[dim]Type [bold]devos help[/] to explore commands.[/]\n")


def project_root(path: Optional[Path] = None) -> Path:
    current = (path or Path.cwd()).expanduser().resolve()
    for candidate in (current, *current.parents):
        if (candidate / ".devos").exists() or (candidate / ".git").exists():
            return candidate
    return current


def iter_files(root: Path):
    for current, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for name in names:
            path = Path(current) / name
            if path.is_file():
                yield path


def scan(root: Path) -> dict:
    files = list(iter_files(root))
    extensions = Counter(p.suffix.lower() or "[no extension]" for p in files)
    source_files = [p for p in files if p.suffix.lower() in SOURCE_EXTENSIONS]
    total_lines = 0
    unreadable = 0
    for path in source_files:
        try:
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                total_lines += sum(1 for _ in handle)
        except OSError:
            unreadable += 1
    return {
        "root": str(root),
        "files": len(files),
        "source_files": len(source_files),
        "lines": total_lines,
        "unreadable": unreadable,
        "extensions": extensions,
    }


def run_git(args: list[str], cwd: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args],
        cwd=cwd,
        text=True,
        capture_output=True,
        check=False,
    )


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context):
    """Launch the DevOS terminal welcome screen."""
    if ctx.invoked_subcommand is None:
        banner()


@app.command()
def init(
    name: str = typer.Argument(..., help="Name or path of the new project."),
    force: bool = typer.Option(False, "--force", help="Allow a non-empty directory."),
):
    """Initialize DevOS metadata in a project directory."""
    target = Path(name).expanduser().resolve()
    if target.exists() and any(target.iterdir()) and not force:
        console.print("[red]Directory is not empty. Use --force to continue.[/]")
        raise typer.Exit(1)
    target.mkdir(parents=True, exist_ok=True)
    metadata = target / ".devos"
    metadata.mkdir(exist_ok=True)
    config = metadata / "config.json"
    if not config.exists():
        config.write_text(json.dumps({
            "project_name": target.name,
            "version": "0.1.0",
            "ai_provider": "none",
            "created_by": "devos"
        }, indent=2), encoding="utf-8")
    console.print(Panel(
        f"[green]DevOS project initialized[/]\n[bold]{target}[/]\n"
        "[dim]Metadata: .devos/config.json[/]",
        border_style="green"
    ))


@app.command()
def open(path: str = typer.Argument(".", help="Project directory to open.")):
    """Open a project in the configured editor, or print its location."""
    target = Path(path).expanduser().resolve()
    if not target.is_dir():
        console.print(f"[red]Directory not found:[/] {target}")
        raise typer.Exit(1)
    editor = os.environ.get("EDITOR")
    if editor:
        try:
            subprocess.Popen([editor, str(target)])
            console.print(f"[green]Opened with {editor}:[/] {target}")
            return
        except OSError as exc:
            console.print(f"[yellow]Could not launch editor: {exc}[/]")
    console.print(f"Project directory: [bold]{target}[/]")


@app.command()
def projects():
    """List DevOS projects registered in the home directory."""
    base = Path.home() / ".devos" / "projects"
    if not base.exists():
        console.print("[yellow]No registered projects yet.[/]")
        console.print("Initialize one with [bold]devos init my-project[/].")
        return
    table = Table(title="Registered DevOS Projects", box=box.ROUNDED)
    table.add_column("Project")
    table.add_column("Path")
    for entry in sorted(base.iterdir()):
        if entry.is_dir():
            table.add_row(entry.name, str(entry))
    console.print(table)


@app.command()
def analyze(path: str = typer.Argument(".", help="Project path to analyze.")):
    """Scan project files, languages, and approximate source line count."""
    root = Path(path).expanduser().resolve()
    if not root.is_dir():
        console.print(f"[red]Project directory not found:[/] {root}")
        raise typer.Exit(1)
    console.print("[cyan]Initializing project intelligence...[/]")
    result = scan(root)
    table = Table(title="Project Analysis", box=box.ROUNDED)
    table.add_column("Metric")
    table.add_column("Result", justify="right")
    for key, label in [
        ("files", "Files discovered"),
        ("source_files", "Source files"),
        ("lines", "Source lines"),
        ("unreadable", "Unreadable files"),
    ]:
        table.add_row(label, str(result[key]))
    console.print(table)
    ext_table = Table(title="File Types", box=box.SIMPLE)
    ext_table.add_column("Extension")
    ext_table.add_column("Count", justify="right")
    for ext, count in result["extensions"].most_common(12):
        ext_table.add_row(ext, str(count))
    console.print(ext_table)
    console.print(f"[dim]Root: {root}[/]")


@app.command()
def explain(
    file: str = typer.Argument(..., help="File to inspect."),
):
    """Print a safe, bounded preview of a source file."""
    path = Path(file).expanduser().resolve()
    if not path.is_file():
        console.print(f"[red]File not found:[/] {path}")
        raise typer.Exit(1)
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        console.print(f"[red]Unable to read file:[/] {exc}")
        raise typer.Exit(1)
    lines = content.splitlines()
    preview = "\n".join(lines[:100])
    console.print(Panel(
        f"[bold]{path.name}[/]  [dim]{len(lines)} lines[/]\n\n"
        f"```text\n{preview}\n```",
        title="File preview",
        border_style="cyan"
    ))
    if len(lines) > 100:
        console.print("[dim]Preview limited to the first 100 lines.[/]")


@app.command()
def review(path: str = typer.Argument(".", help="Project path to review.")):
    """Run basic heuristic checks; this is not a security audit."""
    root = Path(path).expanduser().resolve()
    if not root.is_dir():
        console.print(f"[red]Directory not found:[/] {root}")
        raise typer.Exit(1)
    findings = []
    for file_path in iter_files(root):
        if file_path.suffix.lower() not in SOURCE_EXTENSIONS:
            continue
        try:
            lines = file_path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for number, line in enumerate(lines, 1):
            stripped = line.strip()
            if "TODO" in stripped or "FIXME" in stripped:
                findings.append((file_path, number, "INFO", "TODO/FIXME marker"))
            if file_path.suffix.lower() in {".py", ".js", ".ts"}:
                if "password =" in stripped.lower() or "api_key =" in stripped.lower():
                    findings.append((file_path, number, "WARN", "Possible hard-coded credential assignment"))
                if "eval(" in stripped:
                    findings.append((file_path, number, "WARN", "Use of eval()"))
    table = Table(title="Heuristic Code Review", box=box.ROUNDED)
    table.add_column("Severity")
    table.add_column("Location")
    table.add_column("Finding")
    for file_path, number, severity, message in findings[:200]:
        color = "yellow" if severity == "WARN" else "cyan"
        table.add_row(f"[{color}]{severity}[/]", f"{file_path.relative_to(root)}:{number}", message)
    console.print(table)
    console.print(f"[bold]{len(findings)}[/] finding(s). This heuristic scan can miss issues and produce false positives.")


@app.command()
def diagnose(path: str = typer.Argument(".", help="Project path to inspect.")):
    """Check common project health indicators."""
    root = Path(path).expanduser().resolve()
    if not root.is_dir():
        console.print(f"[red]Directory not found:[/] {root}")
        raise typer.Exit(1)
    checks = [
        ("Git repository", (root / ".git").exists()),
        ("DevOS metadata", (root / ".devos").exists()),
        ("Python project manifest", (root / "pyproject.toml").exists() or (root / "requirements.txt").exists()),
        ("Node project manifest", (root / "package.json").exists()),
        ("README", (root / "README.md").exists()),
        ("Tests directory", any((root / d).is_dir() for d in ("tests", "test", "__tests__"))),
    ]
    table = Table(title="Project Diagnostics", box=box.ROUNDED)
    table.add_column("Check")
    table.add_column("Status")
    for label, passed in checks:
        table.add_row(label, "[green]Detected[/]" if passed else "[dim]Not detected[/]")
    console.print(table)


@app.command()
def debug():
    """Show available local debugging context."""
    root = project_root()
    console.print(Panel(
        f"Working directory: {Path.cwd()}\n"
        f"Detected project root: {root}\n"
        f"Python: {os.sys.version.split()[0]}\n"
        f"Platform: {os.sys.platform}\n"
        f"Editor: {os.environ.get('EDITOR', 'not configured')}",
        title="Debug Context",
        border_style="cyan"
    ))
    console.print("[dim]No debugger is attached. This command reports environment context only.[/]")


@app.command()
def fix():
    """Explain the current safe-fix workflow."""
    console.print("[yellow]Automatic code modification is disabled in this version.[/]")
    console.print("Run [bold]devos review[/] or [bold]devos diagnose[/] first.")
    console.print("A future patch workflow should show a diff and require explicit approval.")


ask_app = typer.Typer(help="AI assistant commands.")
app.add_typer(ask_app, name="agent")


@ask_app.command("status")
def agent_status():
    """Show AI agent integration status."""
    console.print(Panel(
        "Agent runtime: [yellow]Not configured[/]\n"
        "Provider: none\n"
        "Mode: local placeholder\n"
        "Next step: connect a local model or provider adapter.",
        title="DevOS Agent",
        border_style="yellow"
    ))


@ask_app.command("run")
def agent_run(task: str = typer.Argument(..., help="Task description.")):
    """Display the requested task; execution adapter is not connected yet."""
    console.print(f"[bold]Requested task:[/] {task}")
    console.print("[yellow]No agent provider is configured; no files or commands were changed.[/]")


@app.command()
def ask(question: str = typer.Argument(..., help="Question about your project.")):
    """AI assistant entry point (provider integration required)."""
    root = project_root()
    console.print(Panel(
        f"[bold]Question:[/] {question}\n\n"
        f"[bold]Project context:[/] {root}\n\n"
        "[yellow]AI provider is not configured yet.[/]\n"
        "The CLI is ready for a local Ollama or hosted-model adapter.",
        title="DevOS Assistant",
        border_style="cyan"
    ))


git_app = typer.Typer(help="Git repository intelligence.")
app.add_typer(git_app, name="git")


@git_app.command("status")
def git_status(path: str = typer.Argument(".", help="Repository path.")):
    """Show Git working-tree status."""
    root = Path(path).expanduser().resolve()
    if not (root / ".git").exists():
        console.print("[red]No Git repository found at this path.[/]")
        raise typer.Exit(1)
    result = run_git(["status", "--short", "--branch"], root)
    if result.returncode:
        console.print(f"[red]{result.stderr.strip()}[/]")
        raise typer.Exit(result.returncode)
    console.print(Panel(result.stdout.strip() or "Working tree clean.", title="Git Status"))


@git_app.command("history")
def git_history(
    count: int = typer.Option(10, min=1, max=100, help="Number of commits."),
    path: str = typer.Argument(".", help="Repository path."),
):
    """Show recent Git commits."""
    root = Path(path).expanduser().resolve()
    result = run_git(["log", f"-{count}", "--oneline", "--decorate"], root)
    if result.returncode:
        console.print(f"[red]{result.stderr.strip()}[/]")
        raise typer.Exit(result.returncode)
    console.print(Panel(result.stdout.strip() or "No commits found.", title="Recent Git History"))


@git_app.command("analyze")
def git_analyze(path: str = typer.Argument(".", help="Repository path.")):
    """Summarize changed files in the Git working tree."""
    root = Path(path).expanduser().resolve()
    result = run_git(["diff", "--stat"], root)
    staged = run_git(["diff", "--cached", "--stat"], root)
    if result.returncode or staged.returncode:
        console.print("[red]Unable to inspect Git changes. Is this a repository?[/]")
        raise typer.Exit(1)
    console.print(Panel(
        "[bold]Unstaged changes[/]\n" + (result.stdout.strip() or "None") +
        "\n\n[bold]Staged changes[/]\n" + (staged.stdout.strip() or "None"),
        title="Git Change Analysis"
    ))


@app.command()
def status():
    """Show DevOS and runtime status."""
    root = project_root()
    table = Table(title="DevOS System Status", box=box.ROUNDED)
    table.add_column("Component")
    table.add_column("Status")
    table.add_row("CLI", "[green]Operational[/]")
    table.add_row("Project", str(root))
    table.add_row("Git", "[green]Connected[/]" if (root / ".git").exists() else "[dim]Not detected[/]")
    table.add_row("AI agent", "[yellow]Not configured[/]")
    table.add_row("Diagnostics", "[dim]Run devos diagnose[/]")
    console.print(table)


@app.command()
def config():
    """Display DevOS configuration, if initialized."""
    root = project_root()
    config_path = root / ".devos" / "config.json"
    if not config_path.exists():
        console.print("[yellow]No .devos/config.json found.[/]")
        console.print("Run [bold]devos init <project>[/] to initialize a project.")
        return
    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        console.print(f"[red]Invalid configuration:[/] {exc}")
        raise typer.Exit(1)
    console.print_json(data=json.dumps(data, indent=2))


@app.command()
def help():
    """Show the DevOS command guide."""
    table = Table(title="DevOS Command Reference", box=box.ROUNDED)
    table.add_column("Command", style="bold cyan")
    table.add_column("Purpose")
    rows = [
        ("devos init <name>", "Initialize a project"),
        ("devos open <path>", "Open or locate a project"),
        ("devos projects", "List registered projects"),
        ("devos analyze", "Scan files and languages"),
        ("devos explain <file>", "Preview a source file"),
        ("devos review", "Run heuristic code checks"),
        ("devos diagnose", "Check project indicators"),
        ("devos debug", "Show environment context"),
        ("devos fix", "Show safe-fix status"),
        ("devos ask <question>", "AI assistant integration point"),
        ("devos agent status", "Show agent status"),
        ("devos agent run <task>", "Submit an agent task placeholder"),
        ("devos git status", "Show Git status"),
        ("devos git analyze", "Summarize Git changes"),
        ("devos git history", "Show recent commits"),
        ("devos status", "Show DevOS status"),
        ("devos config", "Show project configuration"),
    ]
    for command, purpose in rows:
        table.add_row(command, purpose)
    console.print(table)


if __name__ == "__main__":
    app()
